package de.cdkioskstockmanagement.Texts;


/**
 * Diese Class wird in der Regel immer mit Applikationstexten gefüllt die über Konstante dann einfacher genutztn
 * wertden könnnen
 */
public class AppTexts {
    //region Konstante
    public static final String SERVER_IP = "localhost";
    public static final String DB_NAME = "kiosk";
    public static final String DB_URL = "jdbc:mariadb://" + SERVER_IP + "/" + DB_NAME;
    public static final String USERNAME = "root";
    public static final String PASSWORD = "";
    public static final String SQL_PRODUCTS_TABLE = "products";

    //endregion
    //region Attribute
    //endregion
    //region Konstruktoren
    private AppTexts() {}
    //endregion
    //region Methoden

    //endregion
}
