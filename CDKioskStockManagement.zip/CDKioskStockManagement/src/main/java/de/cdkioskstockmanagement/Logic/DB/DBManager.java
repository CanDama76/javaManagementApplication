package de.cdkioskstockmanagement.Logic.DB;
import de.cdkioskstockmanagement.Model.products;
import de.cdkioskstockmanagement.Texts.AppTexts;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;


/**
 * Im DBManager werden befehle und hintergrundfunktionen zwischen Tool und Datenbank implementiert
 * wie z.B. Credentials Informationen zum Verbinden mit dem Server um auf die Datenbank zugreifen zu können
 *
 */

public class DBManager {
    //region Konstante
    public static final String SELECT_FROM_PRODUCTS = "select * from products";
    public static final String NO_DATABASE_CONNECTION = "Die Datenbankverbindung ist getrennt";
    //endregion
    //region Attribute
    //endregion
    //region Konstruktoren
    //endregion
    //region Methoden

    //Methode um die Verbindung mit hilfe von Credentials herstellen zu können

    /**
     *
     * Dieser Code-Abschnitt ist eine Java-Methode namens "getConnection", die eine Verbindung zu einer Datenbank
     * herstellt und ein Connection-Objekt zurückgibt. Die Methode verwendet die "DriverManager" Klasse von Java, um eine
     * Verbindung zu einer Datenbank herzustellen, indem die URL, den Benutzernamen und das Passwort, die in AppTexts Klasse
     * gespeichert sind, übergeben werden. Wenn die Verbindung erfolgreich hergestellt wurde, gibt die Methode das Connection-Objekt
     * zurück und gibt "Verbindung hergestellt" auf der Konsole aus. Wenn ein Fehler auftritt, wird die Ausnahme eingefangen und die
     * Ausnahme wird auf der Konsole ausgegeben und die Methode gibt "Keine Verbindung möglich!" aus.
     *
     */
    private static Connection getConnection() {

        Connection dbConnection = null;

        //Durchlauf der Anwendung von den Credentials mit Erfolgsnachrichten oder bei einer Exception erscheint eine
        //Fehlermeldung wie unten zu sehen ist "Keine Verbindung möglich"

        try {

            dbConnection = DriverManager.getConnection(AppTexts.DB_URL, AppTexts.USERNAME, AppTexts.PASSWORD);
            System.out.println("Verbindung hergestellt");
        } catch (Exception e) {

            e.printStackTrace();
            System.out.println("Keine Verbindung möglich!");
        }

        return dbConnection;
    }

//    public static int count(String col, String table){
//
//        Connection connection = getConnection();
//        try{
//
//            PreparedStatement preparedStatement = connection.prepareStatement(" select count("+col+")from "+table);
//            ResultSet resultSet=preparedStatement.executeQuery();
//
//            if(resultSet.next()){
//                return Integer.parseInt(resultSet.getString(1));
//            }
//
//
//        } catch (Exception e){
//            e.printStackTrace();
//
//        }finally {
//            try {
//                connection.close();
//                System.out.println();
//            }catch (Exception e){
//                e.printStackTrace();
//            }
//        }
//        return 0;
//    }

    //Formatierung der Einzufügenden Daten durch das Tool in die Datenbank
    public static boolean insert( int id, String name, int amount, double price){

        Connection connection = getConnection();
        PreparedStatement preparedStatement;

        String sql = null;
        sql = "insert into products (id, name, amount, price) " +
                    "Values('" + id + "','" + name + "','" + amount + "','" + price + "')";

        //Durchlauf der Anwendung und Überprüfung der Verbindung bei einer Exception erscheint eine
        //Fehlermeldung wie unten zu sehen ist "Datenbankverbindung getrennt"

        try {


            preparedStatement =connection.prepareStatement(sql);
            return !preparedStatement.execute();

        }catch (Exception e){


            e.printStackTrace();

        }finally {
            try {
                connection.close();
                System.out.println(NO_DATABASE_CONNECTION);
            }catch (Exception e){
                e.printStackTrace();
            }
        }

        return true;
    }

    /**
     * Dieser Code-Abschnitt ist eine Java-Methode mit dem Namen "getProducts", die eine Liste von Produkten aus einer
     * Datenbank abruft und zurückgibt. Die Methode verwendet das "ObservableList" und "FXCollections" von JavaFX, um eine
     * beobachtbare Liste von Produkten zu erstellen. Sie verbindet sich mit einer Datenbank mit Hilfe von "getConnection"
     * Methode und führt dann eine Abfrage auf die Tabelle 'products' aus. Der Abfrageergebnisse werden in ein "ResultSet"
     * gespeichert und dann durchlaufen. Für jeden Datensatz im Ergebnis wird ein neues "products" Objekt erstellt und
     * in die beobachtbare Liste hinzugefügt. Schließlich wird die beobachtbare Liste zurückgegeben.
     *
     */
    public static ObservableList<products> getProducts() {

        Connection connection = getConnection();

        ObservableList<products> list = FXCollections.observableArrayList();

        try {

            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_FROM_PRODUCTS);
            ResultSet resultSet = preparedStatement.executeQuery();


            while (resultSet.next()){

            // Hier sind die Spaltennamen der Tabelle die ebenfalls in der Datenbank ebenso genannt werden somit wird

                list.add(new products(resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getInt("amount"),
                        resultSet.getDouble("price"))
                );
            }


        }catch (Exception e){
            e.printStackTrace();
        }finally {
            try {
                connection.close();
                System.out.println(NO_DATABASE_CONNECTION);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return list;
    }
    //endregion

    /**
     *
     *Dieser Code-Abschnitt ist eine Java-Methode mit dem Namen "delete", die einen Datensatz aus einer Datenbanktabelle "products" löscht.
     * Die Methode erhält ein Argument "where", das die Bedingung für den Datensatz darstellt, der gelöscht werden soll.
     * Die Methode erstellt eine Verbindung zu einer Datenbank mithilfe der Methode getConnection().
     * Dann erstellt sie eine preparedStatement mit einer Abfrage, die ein DELETE-Statement enthält und setzt die
     * Bedingung welche übergeben wurde. Dann wird die Abfrage ausgeführt und es wird überprüft ob die Abfrage erfolgreich war,
     * indem das Ergebnis der execute() Methode negiert wird und zurückgegeben wird. Wenn ein Fehler auftritt, wird die Ausnahme
     * eingefangen und auf der Konsole ausgegeben. Schließlich wird die Verbindung geschlossen.
     */
    public static boolean delete(String where) {

        Connection connection=getConnection();

        try {

            PreparedStatement preparedStatement = connection.prepareStatement("delete from products where "+ where);
            return !preparedStatement.execute();
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            try {
                connection.close();
                System.out.println(NO_DATABASE_CONNECTION);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return false;
    }

    /**
     *
     *Dieser Code-Abschnitt ist eine Java-Methode mit dem Namen "update", die einen Datensatz in einer Datenbanktabelle
     * "products" aktualisiert. Die Methode erhält vier Argumente: "id", "name", "amount" und "price". Diese Argumente
     * werden verwendet, um die neuen Werte für die Spalten "id", "name", "amount" und "price" in der Tabelle zu setzen.
     * Die Methode erstellt eine Verbindung zu einer Datenbank mithilfe der Methode getConnection(). Dann wird ein String
     * mit dem Namen sql erstellt, der ein Update-Statement enthält, das die neuen Werte für die Spalten setzt. Danach
     * wird eine preparedStatement erstellt, die auf das Update-Statement verweist und die Abfrage ausgeführt.
     * Es wird überprüft ob die Abfrage erfolgreich war, indem das Ergebnis der execute() Methode negiert wird und zurückgegeben wird.
     * Wenn ein Fehler auftritt, wird die Ausnahme eingefangen und auf der Konsole ausgegeben. Schließlich wird die Verbindung geschlossen.
     * Es ist zu beachten, dass die Abfrage nicht sicher ist gegen SQL-Injection-Angriffe und dass es besser wäre
     * sicherere Methoden zu verwenden, um die Parameter in die Abfrage einzufügen.
     */

    public static boolean update(String name,int amount,double price){


        Connection connection = getConnection();


                    String sql = "UPDATE `products` SET "
                    +"id ='?' ,"
                    +"name='"+name+"',"
                    +"amount='"+amount+"',"
                    +"price="+price+" WHERE id = '?' ";

//        sql = "UPDATE `products` SET `id`='?',`name`='?',`amount`='?',`price`='?' WHERE id='?'";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            System.out.println(preparedStatement);
            return !preparedStatement.execute();
        }catch (Exception e){
            e.printStackTrace();


        }finally {
            try {
                connection.close();
                System.out.println(NO_DATABASE_CONNECTION);
            }catch (Exception e){
                e.printStackTrace();
            }
        }


        return false;
    }}






