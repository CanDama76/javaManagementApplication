package de.cdkioskstockmanagement.Controller;

import de.cdkioskstockmanagement.Logic.DB.DBManager;
import de.cdkioskstockmanagement.Model.products;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * In der Controller Class werden die Bedienungselemente der JavaFX Applikation mit Funktionen versehen
 * wie z.B. der Button oder das Textfeld
 * @FXML steht als Hinweis zur controler-view.fxml file, welche für den Scenebuilder also auch das Aussehen des Tools
 * zuständig ist
 */


public class Controller implements Initializable {
    ObservableList<products> productList;
    int index = -1;

    @FXML
    TextField txtID;

    @FXML
    TextField txtName;

    @FXML
    TextField txtAmount;

    @FXML
    TextField txtPrice;

    @FXML
    TableView<products> tableProducts;
    @FXML
    TableColumn<Integer, products> colID;
    @FXML
    TableColumn<String, products> colName;
    @FXML
    TableColumn<Integer, products> colAmount;
    @FXML
    TableColumn<Double, products> colPrice;


    //Die Speicherfunktion und gleichzeitig das Einfügen wird durch dieses Inkrement deklariert
    public void insertProducts(){


        int idProduct = Integer.parseInt(txtID.getText());
        String nameProduct = txtName.getText();
        int amountProduct = Integer.parseInt(txtAmount.getText());
        double priceProduct = Double.parseDouble(txtPrice.getText());

        if(DBManager.insert(idProduct,nameProduct,amountProduct,priceProduct)){

            productList.add(new products(idProduct, nameProduct, amountProduct, priceProduct));


        }

    }

    public void getSelectedProducts(){


        index = tableProducts.getSelectionModel().getSelectedIndex();

        //Um eine Exception zu vermieden wird der Index -1 gesetzt

        if(index <= -1){
            return;
        }

        //Textfelder erhalten hier Ihre Zugehörigkeit

        txtID.setText(String.valueOf(colID.getCellData(index)));
        txtName.setText(String.valueOf(colName.getCellData(index)));
        txtAmount.setText(String.valueOf(colAmount.getCellData(index)));
        txtPrice.setText(String.valueOf(colPrice.getCellData(index)));

    }
    //Das Löschen wird durch dieses Inkrement deklariert
    public void deleteProducts(){

        // Falls es nichts hat
        if (index == -1){
            return;
        }


        if (DBManager.delete( "id= "+colID.getCellData(index))){
            System.out.println("Es wurde gelöscht");


            productList.remove(index);
            index = -1;

            clearProduct();

        }

    }
    //Zusatzfunktion für den Button "Säubern" löscht alle derzeitigen Infos die in den Textfeldern eingetragen werden
    //spart zeit um nicht jedes Feld einzeln löschen zu müssen
    public void clearProduct(){
        txtID.clear();
        txtName.clear();
        txtAmount.clear();
        txtPrice.clear();
    }


    //Das aktualisieren des Produktes durch auswahl einer bestimmten Pos. in der Tabelle wird hier durch deklariert
    public void updateProduct(){


        int id = Integer.parseInt(txtID.getText());
        String name = txtName.getText();
        int amount = Integer.parseInt(txtAmount.getText());
        double price = Double.parseDouble(txtPrice.getText());

        if (DBManager.update(name, amount, price)){
            System.out.println("Eine Änderung hat stattgefunden");
            productList.set(index,new products(id,name,amount,price));


            clearProduct();


        }

    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        //Hier wird die Tabelle mit Ihren Bestandteilen aufgefordert sich Visuell sichtbar zu machen

        colID.setCellValueFactory(new PropertyValueFactory<Integer,products>("id"));
        colName.setCellValueFactory(new PropertyValueFactory<String, products>("name"));
        colAmount.setCellValueFactory(new PropertyValueFactory<Integer, products>("amount"));
        colPrice.setCellValueFactory(new PropertyValueFactory<Double, products>("price"));
        productList = DBManager.getProducts();
        tableProducts.setItems(productList);
    }


}