package de.cdkioskstockmanagement.Model;

/**
 * In dieser Class werden die Produktattribute und Methoden festgelegt
 * Getter & Setter helfen Datenabzurufen oder Festzulegen
 * Es werden natürlich auch die Datentypen für die jeweiligen Attribute festgelegt
 */
public class products {
    //region Konstante

    //endregion
    //region Attribute
    int id;
    String name;
    int amount;
    double price;
    //endregion
    //region Konstruktoren
    //endregion
    //region Methoden

    public products(int id, String name, int amount, double price) {
        this.id = id;
        this.name = name;
        this.amount = amount;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAmount() {
        return amount;
    }

    public double getPrice() {
        return price;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    //endregion
}
