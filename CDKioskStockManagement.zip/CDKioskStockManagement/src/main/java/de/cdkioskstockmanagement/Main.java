package de.cdkioskstockmanagement;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * In der Main Class wird das Programm als ganzes gestartet und gewisse Parameter für die GUI ebenfalls festgelegt
 * desweiteren wird die Resourcefile festgelegt über die Funktion "Main.class.getRessource..."
 */

public class Main extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("controller-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        stage.setTitle("KIOSKSTOCKMANAGER2.0");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}