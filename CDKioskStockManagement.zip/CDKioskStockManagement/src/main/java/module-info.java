module de.cdkioskstockmanagement {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.mariadb.jdbc;

    requires com.dlsc.formsfx;

    opens de.cdkioskstockmanagement to javafx.fxml;
    exports de.cdkioskstockmanagement;
    exports de.cdkioskstockmanagement.Controller;
    opens de.cdkioskstockmanagement.Controller to javafx.fxml;
    exports de.cdkioskstockmanagement.Model;
    opens de.cdkioskstockmanagement.Model to javafx.fxml;
}